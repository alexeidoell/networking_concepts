// Alexei Doell cka067 11345642

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <sys/wait.h>
#include <signal.h>
#include <shared.h>

#define PORT "34920"  // the port users will be connecting to

#define BACKLOG 10   // how many pending connections queue will hold

int main(void)
{
    int sockfd, new_fd;  // listen on sock_fd, new connection on new_fd
    struct addrinfo hints, *servinfo, *p;
    struct sockaddr_storage their_addr; // connector's address information
    socklen_t sin_size;
    struct sigaction sa;
    int yes=1;
    char s[INET6_ADDRSTRLEN];
    int rv;

    memset(&hints, 0, sizeof hints);
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_flags = AI_PASSIVE; // use my IP

    if ((rv = getaddrinfo(NULL, PORT, &hints, &servinfo)) != 0) {
        fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(rv));
        return 1;
    }

    // loop through all the results and bind to the first we can
    for(p = servinfo; p != NULL; p = p->ai_next) {
        if ((sockfd = socket(p->ai_family, p->ai_socktype,
                p->ai_protocol)) == -1) {
            perror("tcp server: socket");
            continue;
        }

        if (setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &yes,
                sizeof(int)) == -1) {
            perror("setsockopt");
            exit(1);
        }

        if (bind(sockfd, p->ai_addr, p->ai_addrlen) == -1) {
            close(sockfd);
            perror("tcp server: bind");
            continue;
        }

        break;
    }

    freeaddrinfo(servinfo); // all done with this structure

    if (p == NULL)  {
        fprintf(stderr, "tcp server: failed to bind\n");
        exit(1);
    }

    if (listen(sockfd, BACKLOG) == -1) {
        perror("listen");
        exit(1);
    }

    sa.sa_handler = sigchld_handler; // reap all dead processes
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_RESTART;
    if (sigaction(SIGCHLD, &sa, NULL) == -1) {
        perror("sigaction");
        exit(1);
    }

    printf("tcp server: waiting for connections on %s\n", PORT);

    while(1) {  // main accept() loop
        sin_size = sizeof their_addr;
        new_fd = accept(sockfd, (struct sockaddr *)&their_addr, &sin_size);
        if (new_fd == -1) {
            perror("accept");
            continue;
        }

        inet_ntop(their_addr.ss_family,
            get_in_addr((struct sockaddr *)&their_addr),
            s, sizeof s);
        printf("tcp server: got connection from %s\n", s);

        if (!fork()) { // this is the child process
            close(sockfd); // child doesn't need the listener
            char* msg = NULL;
            int32_t expected;
            int32_t networkbytes;
            while (1) {
                switch(recvloop(new_fd, &expected, sizeof expected)) {
                    case -1:
                        perror("recv");
                        close(new_fd);
                        exit(1);
                    case 0:
                        printf("tcp server: connection from %s closed\n", s);
                        close(new_fd);
                        exit(0);
                }
                expected = ntohl(expected);
                if (!(msg = realloc(msg, expected + 1))) {
                    perror("realloc");
                    close(new_fd);
                    exit(1);
                }
                switch(recvloop(new_fd, msg, expected)) {
                    case -1:
                        perror("recv");
                        close(new_fd);
                        exit(1);
                    case 0:
                        printf("tcp server: connection from %s closed\n", s);
                        close(new_fd);
                        exit(0);
                    default:
                        networkbytes = htonl(expected);
                        cipher(msg, expected);
                        if (send(new_fd, &networkbytes, sizeof networkbytes, 0) == -1) {
                            perror("send");
                            close(new_fd);
                            exit(1);
                        }
                        if (send(new_fd, msg, expected, 0) == -1) {
                            perror("send");
                            close(new_fd);
                            exit(1);
                        }
                }
            }
        }
        close(new_fd);  // parent doesn't need this but also this will probably
                        // never actually ever be called
    }

    return 0;
}
